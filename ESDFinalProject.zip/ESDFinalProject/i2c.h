/*
 * Name: i2c.h
 * Author: Rakesh Kumar
 * Tools Used: CCS
 * Leveraged Code: Code samples from the TI have been referred for development
 * Links:
 *
 */
#ifndef _I2C_H_
#define _I2C_H_

#include <ti/devices/msp432p4xx/driverlib/driverlib.h>

/* Standard Includes */
#include <stdint.h>
#include <stdbool.h>
#include <string.h>

/* Slave Address for I2C Slave */
#define SLAVE_ADDRESS       0x40
#define NUM_OF_REC_BYTES    1

/* Variables */
void read_register(uint8_t i2c_register);
void init_registers_ina219(void);

#endif /* _I2C_H_ */
