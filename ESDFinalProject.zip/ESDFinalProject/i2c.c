/* Name: i2c.c
 * Author: Rakesh Kumar
 * Tools Used: CCS
 * Leveraged Code:  TI SimpleLink DriverLib Examples have been referred for the implementation
 * Links:
 */

#include "i2c.h"

//Data to be used for setting up the registers of the INA219
const uint8_t TXData[] = {0x80,0x00,0x7B,0xC7,0x80,0x00,0x81};
extern uint16_t data;
/* I2C Master Configuration Parameter */
#if 1
const eUSCI_I2C_MasterConfig i2cConfig =
{
        EUSCI_B_I2C_CLOCKSOURCE_SMCLK,          // SMCLK Clock Source
        48000000,                               //SMCLK = 48MHz
        EUSCI_B_I2C_SET_DATA_RATE_100KBPS,      // Desired I2C Clock of 100khz
        0,                                      // No byte counter threshold
        EUSCI_B_I2C_NO_AUTO_STOP                // No Autostop
};
#endif

/* Name: read_register()
 * Use: This function carries out the operation of reading the values of the specified register
 * params: the respective register to be read
 * return: void
 */
void read_register(uint8_t i2c_register)
{
    data = 0;
    MAP_I2C_masterSendMultiByteStart(EUSCI_B0_BASE,i2c_register);
    while(!(EUSCI_B0->IFG & EUSCI_B_IFG_TXIFG0));
    EUSCI_B0->CTLW0 |= EUSCI_B_CTLW0_TXSTP;

    // Send the restart condition, read one byte, send the stop condition right away
    EUSCI_B0->CTLW0 &= ~(EUSCI_B_CTLW0_TR);
    EUSCI_B0->CTLW0 |= EUSCI_B_CTLW0_TXSTT;

    while(MAP_I2C_masterIsStartSent(EUSCI_B0_BASE));

    //EUSCI_B1->CTLW0 |= EUSCI_B_CTLW0_TXSTP;
    while(!(EUSCI_B0->IFG & EUSCI_B_IFG_RXIFG0))
    data = EUSCI_B0->RXBUF;

    while(!(EUSCI_B0->IFG & EUSCI_B_IFG_RXIFG0));
    data = (data << 8);

    //Data available in this variable
    data |= EUSCI_B0->RXBUF;
}

/* Name: init_registers_ina219()
 * Use: This function initializes the registers, for the configuration and calibration of the INA219
 * params: void
 * return: void
 */
void init_registers_ina219(void)
{
    MAP_GPIO_setAsPeripheralModuleFunctionInputPin(GPIO_PORT_P1,
               GPIO_PIN6 + GPIO_PIN7, GPIO_PRIMARY_MODULE_FUNCTION);
    /* Initializing I2C Master to SMCLK at 100khz with no autostop */
    MAP_I2C_initMaster(EUSCI_B0_BASE, &i2cConfig);

    /* Specify slave address */
    MAP_I2C_setSlaveAddress(EUSCI_B0_BASE, SLAVE_ADDRESS);

    /* Enable I2C Module to start operations */
    MAP_I2C_enableModule(EUSCI_B0_BASE);

    // Start + 1Byte
    MAP_I2C_masterSendMultiByteStart(EUSCI_B0_BASE, TXData[0]);

    MAP_I2C_masterSendMultiByteNext(EUSCI_B0_BASE, TXData[2]);
    MAP_I2C_masterSendMultiByteFinish(EUSCI_B0_BASE, TXData[3]);

    // Re-Start + 1Byte
    MAP_I2C_masterSendMultiByteStart(EUSCI_B0_BASE, 0x85);

    MAP_I2C_masterSendMultiByteNext(EUSCI_B0_BASE, 0x10);

    MAP_I2C_masterSendMultiByteFinish(EUSCI_B0_BASE, 0x00);
}

